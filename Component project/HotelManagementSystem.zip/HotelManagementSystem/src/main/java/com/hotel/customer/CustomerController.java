package com.hotel.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
	@Autowired
	private IReservation reservation;
	
	@Autowired 
	private IData data;
	
	@Autowired
	private IBillingSystem billingSystem;
	
	@GetMapping("/reservation/create")
	public String createReservation(@RequestParam String guestName,
									@RequestParam int roomNumber,
									@RequestParam String checkIn,
									@RequestParam String checkOut) {
		reservation.createReservation(guestName,  roomNumber,  checkIn,  checkOut);
		return "A reservation created for "+ guestName;
	}
	@GetMapping("/reservation/history")
	public String getHistory(@RequestParam int guestId) {
		return reservation.getReservationHistory(guestId);
		
	}
	
	@GetMapping("/reservation/nights")
	public int getNights(@RequestParam String checkIn, @RequestParam String checkOut) {
	return reservation.calculateNights(checkIn, checkOut);
	}
	
	@GetMapping("/data/guest")
	public String getGuestData(@RequestParam int guestId) {
	return data.retrieveGuestData(guestId);	
	}
	
	@GetMapping("/data/billing")
	public String getBilling(@RequestParam boolean approval, @RequestParam String billingData) {
	return data.getBillingVerification(approval, billingData);	
	
	}
	
	@PostMapping("/billing/paymentmethod")
	public String setPayment(@RequestParam String paymentMethod) {
		billingSystem.setPaymentMethod(paymentMethod);
		return "payment method set:" + paymentMethod;
	}
	
	
	@PostMapping("/billing/process")
	public String processPayment(@RequestParam double amount) {
		boolean result= billingSystem.processPayment(amount);
		return "payment processed:" + result;
	}
	
	@GetMapping("/billing/verify")
	public String verifyBilling(@RequestParam int guestId, @RequestParam double amount) {
		return billingSystem.generateBillingVerification(guestId, amount);
	}

}

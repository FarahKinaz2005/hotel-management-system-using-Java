package com.hotel.billing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hotel.kitchen.IOrders;
@Service
public class BillingAndPaymentImpl implements IBillingAndPayment{

	
	
	@Autowired
    private IOrders orders; 
	
	 @Override
	    public void generateBill(int guestId, String guestName, 
	                             String checkIn, String checkOut) {
	        
	        String orderDetails = orders.trackOrder(guestId);
	        System.out.println("Generating bill for: " + guestName + 
	                           " including kitchen orders: " + orderDetails);
	    }
	
	@Override
	public void getReservation(int guestId, String guestName, int roomNumber, String checkIn, String checkOut) {
		// TODO Auto-generated method stub
		System.out.println("getting reservation: "+ guestId+ guestName+ roomNumber+ checkIn+ checkOut);
	}

	@Override
	public String applyDiscount(int guestId, String promoCode, double eventPrice) {
		// TODO Auto-generated method stub
		return "applying discount"+ guestId+ promoCode+ eventPrice;
	}

	@Override
	public String getBillingHistory(String cardHolderName, int guestId, String guestName, String recentReceipt,
			String guestData, String salesAndEvent, String promoCode) {
		// TODO Auto-generated method stub
		return "getting billing history for: " + guestName+ guestId+ cardHolderName+ recentReceipt+ guestData+ salesAndEvent+ promoCode;
	}

}

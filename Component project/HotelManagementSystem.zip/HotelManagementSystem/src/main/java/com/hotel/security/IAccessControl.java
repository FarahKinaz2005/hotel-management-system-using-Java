package com.hotel.security;

public interface IAccessControl {
	void staffAccess(int staffId, String staffName, String staffMail, String staffSchedule, String staffRole, double staffSalary);
	void guestAccess(int guestId, String guestName, String guestMail, String guestPayments, String guestData);
	String checkStaffPermission(int staffId);
	String checkGuestPermission(int guestId);
	String deleteStaffAccess(int staffId);
	String deleteGuestAccess(int guestId);
}

package com.hotel.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepo;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody user loginRequest) {
        user user = userRepo.findByUsernameAndPassword(
            loginRequest.getUsername(), loginRequest.getPassword());
        if (user == null)
            return ResponseEntity.status(401).body("Invalid credentials");
        return ResponseEntity.ok(user);
    }
}
package com.hotel.services;

import org.springframework.stereotype.Service;

@Service
public class HouseKeepingServiceImpl implements IHouseKeepingService {

    @Override
    public void assignRoomCleaning(int roomNumber) {
        System.out.println("Cleaning assigned for room " + roomNumber);
    }

    @Override
    public void markRoomClean(int roomNumber) {
        System.out.println("Room " + roomNumber + " marked as clean");
    }

    @Override
    public void markRoomDirty(int roomNumber) {
        System.out.println("Room " + roomNumber + " marked as dirty");
    }

    @Override
    public void scheduleInspection(int roomNumber) {
        System.out.println("Inspection scheduled for room " + roomNumber);
    }

    @Override
    public String getRoomCondition(int roomNumber) {
        return "Room " + roomNumber + " condition: Clean";
    }
}
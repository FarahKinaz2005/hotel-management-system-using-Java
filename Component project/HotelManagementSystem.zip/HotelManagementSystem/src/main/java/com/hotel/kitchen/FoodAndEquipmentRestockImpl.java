package com.hotel.kitchen;

import org.springframework.stereotype.Service;

@Service
public class FoodAndEquipmentRestockImpl implements IFoodAndEquipmentRestock {

    @Override
    public void getRestockAlert(int ingredientId, boolean ingredientAvailability) {
        System.out.println("Restock alert for ingredient: " + ingredientId + 
                           " availability: " + ingredientAvailability);
    }

    @Override
    public String stockRequest(int ingredientId) {
        return "Stock requested for ingredient: " + ingredientId;
    }

    @Override
    public String deliveryConfirmation(int ingredientOrderId, String orderDetails, 
                                       String deliveryDate) {
        return "Delivery confirmed for order: " + ingredientOrderId + 
               " details: " + orderDetails + 
               " date: " + deliveryDate;
    }

    @Override
    public String updateInventory(int ingredientId, int stockNumber) {
        return "Inventory updated for ingredient: " + ingredientId + 
               " new stock: " + stockNumber;
    }
}
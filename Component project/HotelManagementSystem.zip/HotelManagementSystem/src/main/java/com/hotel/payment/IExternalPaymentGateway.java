package com.hotel.payment;

public interface IExternalPaymentGateway {
    boolean processPayment(int guestId, String cardNumber, 
                           double amount, String cardType);
    String confirmPayment(int guestId, double amount);
    String refundPayment(int guestId, double amount);
    String getPaymentStatus(int guestId);
}
package com.hotel.kitchen;
import org.springframework.stereotype.Service;
@Service
public class OrderImpl implements IOrders {

	@Override
	public void placeOrder(int orderId, int guestId, String placeOrder) {
		// TODO Auto-generated method stub
		System.out.println("order placed:"+ orderId+ guestId+ placeOrder);
	}

	@Override
	public String trackOrder(int orderId) {
		// TODO Auto-generated method stub
		return "tracking order number:" + orderId;
	}

	@Override
	public String restockAlert(int productId, boolean productAvailability, int numProducts, String productName) {
		// TODO Auto-generated method stub
		return "product needs to be restocked:"+ productId+ productAvailability+ numProducts+ productName;
	}

	@Override
	public String orderCancellation(int orderId) {
		// TODO Auto-generated method stub
		return "order " + orderId+ " is cancelled";
	}

}

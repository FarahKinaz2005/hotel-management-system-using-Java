package com.hotel.services;

public interface IMaintenance {
    void logIssue(int roomNumber, String issue);
    void assignTechnician(int roomNumber, String technicianName);
    String checkIssueStatus(int roomNumber);
    String resolveIssue(int roomNumber);
}
package com.hotel.staff;

public interface IShiftSchedule {
    void createShift(int staffId, String shiftDate, 
                     String startTime, String endTime);
    String getWeeklySchedule(int staffId);
    String updateShift(int staffId, String shiftDate, 
                       String newStartTime, String newEndTime);
    String cancelShift(int staffId, String shiftDate);
}
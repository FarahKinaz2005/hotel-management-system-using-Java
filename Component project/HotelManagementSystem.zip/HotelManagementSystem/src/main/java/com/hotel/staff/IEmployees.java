package com.hotel.staff;

public interface IEmployees {
    void addEmployee(int staffId, String staffName, 
                     String staffRole, double staffSalary);
    String getEmployeeDetails(int staffId);
    String updateEmployee(int staffId, String staffRole, 
                          double staffSalary);
    String removeEmployee(int staffId);
}
package com.hotel.customer;
import org.springframework.stereotype.Service;
@Service
public class BillingSystemImpl implements IBillingSystem {

	@Override
	public void setPaymentMethod(String paymentMethod) {
		// TODO Auto-generated method stub
		System.out.println("setting the payment method"+ paymentMethod);
	}

	@Override
	public boolean processPayment(double amount) {
		// TODO Auto-generated method stub
		System.out.println("Processing payment of: " + amount);
		return true;
	}

	@Override
	public String generateBillingVerification(int guestId, double amount) {
		// TODO Auto-generated method stub
		return "verifying the billing address for guest numebr"+ guestId+ "amount:" +amount ;
	}

}

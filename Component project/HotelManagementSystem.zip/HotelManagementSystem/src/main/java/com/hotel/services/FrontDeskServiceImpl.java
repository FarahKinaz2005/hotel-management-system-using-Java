package com.hotel.services;

import org.springframework.stereotype.Service;

@Service
public class FrontDeskServiceImpl implements IFrontDeskService {

    @Override
    public void checkIn(String guestName, int roomNumber) {
        System.out.println(guestName + " checked into room " + roomNumber);
    }

    @Override
    public void checkOut(String guestName, int roomNumber) {
        System.out.println(guestName + " checked out of room " + roomNumber);
    }

    @Override
    public String getRoomStatus(int roomNumber) {
        return "Room " + roomNumber + " is available";
    }

    @Override
    public void assignRoom(String guestName, int roomNumber) {
        System.out.println("Room " + roomNumber + " assigned to " + guestName);
    }

    @Override
    public void registerGuest(String name, String id) {
        System.out.println("Guest registered: " + name + " ID: " + id);
    }

    @Override
    public void issueRoomKey(int roomNumber) {
        System.out.println("Key issued for room " + roomNumber);
    }

    @Override
    public void deactivateRoomKey(int roomNumber) {
        System.out.println("Key deactivated for room " + roomNumber);
    }
}
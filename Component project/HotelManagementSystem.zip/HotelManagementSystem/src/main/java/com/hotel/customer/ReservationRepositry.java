package com.hotel.customer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepositry extends JpaRepository<Reservation, Long> {
}
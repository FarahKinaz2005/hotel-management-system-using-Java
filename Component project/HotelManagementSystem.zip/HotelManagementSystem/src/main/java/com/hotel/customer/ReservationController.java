package com.hotel.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ReservationController {

    @Autowired
    private ReservationRepositry reservationRepo;

    @PostMapping("/reservations")
    public ResponseEntity<?> createReservation(@RequestBody Reservation res) {
        reservationRepo.save(res);
        return ResponseEntity.ok("Reservation saved successfully");
    }

    @GetMapping("/reservations")
    public List<Reservation> getAllReservations() {
        return reservationRepo.findAll();
    }
}
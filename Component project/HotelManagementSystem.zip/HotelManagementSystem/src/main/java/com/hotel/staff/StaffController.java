package com.hotel.staff;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/staff")
public class StaffController {

    @Autowired
    private IEmployees employees;

    @Autowired
    private IRoles roles;

    @Autowired
    private IShiftSchedule shiftSchedule;

    // Employee endpoints
    @PostMapping("/employees/add")
    public String addEmployee(@RequestParam int staffId,
                              @RequestParam String staffName,
                              @RequestParam String staffRole,
                              @RequestParam double staffSalary) {
        employees.addEmployee(staffId, staffName, staffRole, staffSalary);
        return "Employee added: " + staffName;
    }

    @GetMapping("/employees/details")
    public String getEmployeeDetails(@RequestParam int staffId) {
        return employees.getEmployeeDetails(staffId);
    }

    @PutMapping("/employees/update")
    public String updateEmployee(@RequestParam int staffId,
                                 @RequestParam String staffRole,
                                 @RequestParam double staffSalary) {
        return employees.updateEmployee(staffId, staffRole, staffSalary);
    }

    @DeleteMapping("/employees/remove")
    public String removeEmployee(@RequestParam int staffId) {
        return employees.removeEmployee(staffId);
    }

    // Roles endpoints
    @PostMapping("/roles/assign")
    public String assignRole(@RequestParam int staffId,
                             @RequestParam String roleName) {
        roles.assignRole(staffId, roleName);
        return "Role assigned to staff: " + staffId;
    }

    @GetMapping("/roles/permissions")
    public String getRolePermissions(@RequestParam String roleName) {
        return roles.getRolePermissions(roleName);
    }

    @PutMapping("/roles/update")
    public String updateRole(@RequestParam int staffId,
                             @RequestParam String newRole) {
        return roles.updateRole(staffId, newRole);
    }

    @DeleteMapping("/roles/remove")
    public String removeRole(@RequestParam int staffId,
                             @RequestParam String roleName) {
        return roles.removeRole(staffId, roleName);
    }

    // Shift Schedule endpoints
    @PostMapping("/shifts/create")
    public String createShift(@RequestParam int staffId,
                              @RequestParam String shiftDate,
                              @RequestParam String startTime,
                              @RequestParam String endTime) {
        shiftSchedule.createShift(staffId, shiftDate, startTime, endTime);
        return "Shift created for staff: " + staffId;
    }

    @GetMapping("/shifts/schedule")
    public String getWeeklySchedule(@RequestParam int staffId) {
        return shiftSchedule.getWeeklySchedule(staffId);
    }

    @PutMapping("/shifts/update")
    public String updateShift(@RequestParam int staffId,
                              @RequestParam String shiftDate,
                              @RequestParam String newStartTime,
                              @RequestParam String newEndTime) {
        return shiftSchedule.updateShift(staffId, shiftDate, 
                                         newStartTime, newEndTime);
    }

    @DeleteMapping("/shifts/cancel")
    public String cancelShift(@RequestParam int staffId,
                              @RequestParam String shiftDate) {
        return shiftSchedule.cancelShift(staffId, shiftDate);
    }
}
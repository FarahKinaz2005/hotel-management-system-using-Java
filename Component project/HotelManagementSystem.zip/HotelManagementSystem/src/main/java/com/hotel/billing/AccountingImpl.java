package com.hotel.billing;
import org.springframework.stereotype.Service;
@Service
public class AccountingImpl implements IAccounting{

	@Override
	public void recordTransaction(String cardHolderName, int guestId, String guestName, String recentReciept,
			String guestData, String salesAndEvent, String promoCode) {
		// TODO Auto-generated method stub
		System.out.println("transaction recorded for "+ guestName+ "! transaction details:" + guestName+ guestId+ cardHolderName+ recentReciept+ salesAndEvent+ promoCode+ guestData);
	}

	@Override
	public String getFinancialReport(String financialReport, String guestName, String guestData, String salesAndEvent,
			String promoCode) {
		// TODO Auto-generated method stub
		return "getting financial report:"+ financialReport + guestName+ guestData+ salesAndEvent+ promoCode;
	}

	@Override
	public String requestRefund(String cardHolderName, int guestId, String guestName, String recentReceipt,
			String guestData) {
		// TODO Auto-generated method stub
		return "refund requested for:" + guestName  + "current data:"+ cardHolderName+ recentReceipt+ guestData;
	}

	@Override
	public String getAccountBalance(String cardHolderName, int guestId, double currentBalance) {
		// TODO Auto-generated method stub
		return "getting account balance:"+ cardHolderName+ guestId+ currentBalance;
	}

	@Override
	public String getBillingCustomerData(int guestId, String guestName) {
	    return "Billing customer data for guest: " + guestId + 
	           " name: " + guestName;
	}
}

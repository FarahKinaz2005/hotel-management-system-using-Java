package com.hotel.security;

public interface IIncidentReport {
    void reportGuestIncident(int guestId, String report);
    void reportStaffIncident(int staffId, String report);
    String getIncidentReport(int incidentId);
    String updateIncidentReport(int incidentId, String update);
    String resolveIncident(int incidentId);
}
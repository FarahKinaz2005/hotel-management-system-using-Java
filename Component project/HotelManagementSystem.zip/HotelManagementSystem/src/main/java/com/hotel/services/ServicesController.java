package com.hotel.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/services")
public class ServicesController {

    @Autowired
    private IFrontDeskService frontDeskService;

    @Autowired
    private IHouseKeepingService houseKeepingService;

    @Autowired
    private IConciergeService conciergeService;

    @Autowired
    private IReservationInformation reservationInformation;

    @Autowired
    private ISpaService spaService;

    @Autowired
    private IMaintenance maintenance;

     @PostMapping("/frontdesk/checkin")
    public String checkIn(@RequestParam String guestName,
                          @RequestParam int roomNumber) {
        frontDeskService.checkIn(guestName, roomNumber);
        return guestName + " checked into room " + roomNumber;
    }

    @PostMapping("/frontdesk/checkout")
    public String checkOut(@RequestParam String guestName,
                           @RequestParam int roomNumber) {
        frontDeskService.checkOut(guestName, roomNumber);
        return guestName + " checked out of room " + roomNumber;
    }

    @GetMapping("/frontdesk/roomstatus")
    public String getRoomStatus(@RequestParam int roomNumber) {
        return frontDeskService.getRoomStatus(roomNumber);
    }

    @PostMapping("/frontdesk/assignroom")
    public String assignRoom(@RequestParam String guestName,
                             @RequestParam int roomNumber) {
        frontDeskService.assignRoom(guestName, roomNumber);
        return "Room " + roomNumber + " assigned to " + guestName;
    }

    @PostMapping("/frontdesk/register")
    public String registerGuest(@RequestParam String name,
                                @RequestParam String id) {
        frontDeskService.registerGuest(name, id);
        return "Guest registered: " + name;
    }

     @PostMapping("/housekeeping/clean")
    public String markClean(@RequestParam int roomNumber) {
        houseKeepingService.markRoomClean(roomNumber);
        return "Room " + roomNumber + " marked clean";
    }

    @PostMapping("/housekeeping/dirty")
    public String markDirty(@RequestParam int roomNumber) {
        houseKeepingService.markRoomDirty(roomNumber);
        return "Room " + roomNumber + " marked dirty";
    }

    @GetMapping("/housekeeping/condition")
    public String getRoomCondition(@RequestParam int roomNumber) {
        return houseKeepingService.getRoomCondition(roomNumber);
    }

     @PostMapping("/concierge/request")
    public String handleRequest(@RequestParam String guestName,
                                @RequestParam String request) {
        conciergeService.handleGuestRequest(guestName, request);
        return "Request handled for " + guestName;
    }

    @PostMapping("/concierge/taxi")
    public String bookTaxi(@RequestParam String guestName,
                           @RequestParam String destination) {
        conciergeService.bookTaxi(guestName, destination);
        return "Taxi booked for " + guestName;
    }

    @GetMapping("/concierge/services")
    public String getServices() {
        return conciergeService.getAvailableServices();
    }

     @PostMapping("/reservation/create")
    public String createReservation(@RequestParam String guestName,
                                    @RequestParam int roomNumber,
                                    @RequestParam String date) {
        reservationInformation.createReservation(guestName, roomNumber, date);
        return "Reservation created for " + guestName;
    }

    @DeleteMapping("/reservation/cancel")
    public String cancelReservation(@RequestParam int reservationId) {
        reservationInformation.cancelReservation(reservationId);
        return "Reservation " + reservationId + " cancelled";
    }

    @GetMapping("/reservation/availability")
    public String checkAvailability(@RequestParam String date) {
        return reservationInformation.checkAvailability(date);
    }

     @PostMapping("/spa/book")
    public String bookSpa(@RequestParam String guestName,
                          @RequestParam String sessionType) {
        spaService.bookSpaSession(guestName, sessionType);
        return guestName + " booked: " + sessionType;
    }

    @GetMapping("/spa/menu")
    public String getSpaMenu() {
        return spaService.getSpaMenu();
    }

    @GetMapping("/spa/availability")
    public String checkSpaAvailability(@RequestParam String date) {
        return spaService.checkSpaAvailability(date);
    }

     @PostMapping("/maintenance/log")
    public String logIssue(@RequestParam int roomNumber,
                           @RequestParam String issue) {
        maintenance.logIssue(roomNumber, issue);
        return "Issue logged for room " + roomNumber;
    }

    @PostMapping("/maintenance/assign")
    public String assignTechnician(@RequestParam int roomNumber,
                                   @RequestParam String technicianName) {
        maintenance.assignTechnician(roomNumber, technicianName);
        return "Technician assigned to room " + roomNumber;
    }

    @GetMapping("/maintenance/status")
    public String checkStatus(@RequestParam int roomNumber) {
        return maintenance.checkIssueStatus(roomNumber);
    }

    @PutMapping("/maintenance/resolve")
    public String resolveIssue(@RequestParam int roomNumber) {
        return maintenance.resolveIssue(roomNumber);
    }
}
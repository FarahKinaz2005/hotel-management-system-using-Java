package com.hotel.services;

public interface IFrontDeskService {
    void checkIn(String guestName, int roomNumber);
    void checkOut(String guestName, int roomNumber);
    String getRoomStatus(int roomNumber);
    void assignRoom(String guestName, int roomNumber);
    void registerGuest(String name, String id);
    void issueRoomKey(int roomNumber);
    void deactivateRoomKey(int roomNumber);
}
package com.hotel.kitchen;

public interface IRecipeandInventory {
	void storeRecipe(int recipeId, String recipeIngredients, int ingredientId);
	String trackIngredientStock(int ingredientId);
	String availability(int ingredientId, boolean ingredientAvalability);
	String updateIngredientAvailability(int ingredientId, int stockNumber);
	String stockAlert(int ingredientId, String alertStock, int stockNumber);
}

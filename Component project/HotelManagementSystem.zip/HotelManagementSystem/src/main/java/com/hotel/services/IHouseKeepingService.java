package com.hotel.services;

public interface IHouseKeepingService {
    void assignRoomCleaning(int roomNumber);
    void markRoomClean(int roomNumber);
    void markRoomDirty(int roomNumber);
    void scheduleInspection(int roomNumber);
    String getRoomCondition(int roomNumber);
}
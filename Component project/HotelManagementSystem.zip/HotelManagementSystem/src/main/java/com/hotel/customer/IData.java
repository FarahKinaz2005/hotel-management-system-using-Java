package com.hotel.customer;

public interface IData {
	void getReservation(int guestId, String guestName, int roomNumber, String checkIn, String checkOut);
	String getBillingVerification(Boolean approval, String billingData);
	String visaData(String cardHolderName, String cardNumber, String cardCVV, String expireDate, String cardType );
	String retrieveGuestData(int guestId);
	String getVerifiedGuestData(int guestId);
	void saveToDatabase(String data);
	String retrieveFromDatabase(int id);
}

package com.hotel.services;

public interface IConciergeService {
    void handleGuestRequest(String guestName, String request);
    void bookTaxi(String guestName, String destination);
    void arrangeTouring(String guestName, String tourName);
    String getAvailableServices();
}
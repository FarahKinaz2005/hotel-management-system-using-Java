package com.hotel.customer;

public interface IReservation {
	void createReservation(String guestName, int roomNumber, String CheckIn, String CheckOut);
	String getReservationHistory(int guestId);
	int calculateNights(String checkIn, String CheckOut);
	Double calcTotService(int nights, String[] addOnsService);
	Double applyPromoCode(Double total, String promoCode);
	String getCustomerProfile(int guestId);
}

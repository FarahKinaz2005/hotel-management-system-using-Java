package com.hotel.billing;

public interface IBillingAndPayment {
	void generateBill(int guestId, String guestName, String checkIn, String checkOut  );
	void getReservation(int guestId, String guestName, int roomNumber, String checkIn, String checkOut);
	String applyDiscount(int guestId, String promoCode, double eventPrice);
	String getBillingHistory(String cardHolderName, int guestId, String guestName, String recentReceipt,String guestData, String salesAndEvent, String promoCode);
}

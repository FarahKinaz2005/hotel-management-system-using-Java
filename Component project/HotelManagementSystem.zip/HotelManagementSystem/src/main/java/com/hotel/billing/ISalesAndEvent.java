package com.hotel.billing;

public interface ISalesAndEvent {
	void bookEvent(int guestId, String guestName, String eventName, double eventPrice, double eventSales );
	String cancelEvent(int guestId, String guestName, String eventName, double eventPrice, double eventSales );
	String getSalesReport(int guestId, String guestName, String eventName, double eventPrice, double eventSales );
	String guestSalesData(int guestId, String guestName, String eventName, double eventPrice, double eventSales, String promoCode );
	String getSalesHistory(int guestId);
	String getSalesAndEvents(int guestId);
	String addVoucher(int guestId, String promoCode, double eventPrice);
}

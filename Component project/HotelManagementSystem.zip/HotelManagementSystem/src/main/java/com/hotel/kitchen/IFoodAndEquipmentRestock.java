package com.hotel.kitchen;

public interface IFoodAndEquipmentRestock {
    void getRestockAlert(int ingredientId, boolean ingredientAvailability);
    String stockRequest(int ingredientId);
    String deliveryConfirmation(int ingredientOrderId, String orderDetails, 
                                String deliveryDate);
    String updateInventory(int ingredientId, int stockNumber);
}
package com.hotel.staff;

public interface IRoles {
    void assignRole(int staffId, String roleName);
    String getRolePermissions(String roleName);
    String updateRole(int staffId, String newRole);
    String removeRole(int staffId, String roleName);
}
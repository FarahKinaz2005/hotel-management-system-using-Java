package com.hotel.kitchen;

public interface IMenuManager {
	void createMenu(String menu, int itemId, boolean itemAvailability, double price);
	String getMenu(String menu);
	String deleteItem(int itemId);
	String updateItem(int itemId, boolean itemAvailability, double price);
	
}

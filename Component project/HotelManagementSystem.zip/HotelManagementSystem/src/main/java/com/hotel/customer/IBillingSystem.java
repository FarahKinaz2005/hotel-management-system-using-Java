package com.hotel.customer;

public interface IBillingSystem {
	void setPaymentMethod(String paymentMethod);
	boolean processPayment(double amount);
	String generateBillingVerification(int guestId, double amount);
	
}

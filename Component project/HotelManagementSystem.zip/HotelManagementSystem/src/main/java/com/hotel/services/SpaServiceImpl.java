package com.hotel.services;

import org.springframework.stereotype.Service;

@Service
public class SpaServiceImpl implements ISpaService {

    @Override
    public void bookSpaSession(String guestName, String sessionType) {
        System.out.println(guestName + " booked spa: " + sessionType);
    }

    @Override
    public void cancelBooking(String guestName, int bookingId) {
        System.out.println(guestName + " cancelled booking " + bookingId);
    }

    @Override
    public String checkSpaAvailability(String date) {
        return "Spa available on " + date + " at 10am, 2pm, 4pm";
    }

    @Override
    public String getSpaMenu() {
        return "Services: Massage, Facial, Sauna, Jacuzzi";
    }
}
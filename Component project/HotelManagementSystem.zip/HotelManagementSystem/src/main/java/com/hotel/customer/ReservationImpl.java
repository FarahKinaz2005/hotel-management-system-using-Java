package com.hotel.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReservationImpl implements IReservation {

    @Autowired
    private GuestRepository guestRepository;

	 
	@Override
	public void createReservation(String guestName, int roomNumber,
	                               String checkIn, String checkOut) {
	    Guest guest = new Guest();
	    guest.setGuestName(guestName);
	    guest.setRoomNumber(roomNumber);
	    guest.setCheckIn(checkIn);
	    guest.setCheckOut(checkOut);
	    guestRepository.save(guest);
	    System.out.println("Saved to DB: " + guestName);
	}

	@Override
	public String getReservationHistory(int guestId) {
	    return guestRepository.findById(guestId)
	           .map(g -> "Guest: " + g.getGuestName() + 
	                     " Room: " + g.getRoomNumber())
	           .orElse("Guest not found");
	}

    @Override
    public int calculateNights(String checkIn, String checkOut) {
        System.out.println("Total Payment:");
        return 3;
    }

    @Override
    public Double calcTotService(int nights, String[] addOnsService) {
        System.out.println("calculating total for " + nights + " nights");
        return nights * 100.0;
    }

    @Override
    public Double applyPromoCode(Double total, String promoCode) {
        System.out.println("Applying PromoCode" + promoCode);
        return total * 0.9;
    }

    @Override
    public String getCustomerProfile(int guestId) {
        return "Customer profile for guest ID: " + guestId;
    }
}
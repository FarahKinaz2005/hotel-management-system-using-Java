package com.hotel.staff;

import org.springframework.stereotype.Service;

@Service
public class EmployeeImpl implements IEmployees {

    @Override
    public void addEmployee(int staffId, String staffName, 
                            String staffRole, double staffSalary) {
        System.out.println("Employee added: " + staffName + 
                           " ID: " + staffId + 
                           " Role: " + staffRole + 
                           " Salary: " + staffSalary);
    }

    @Override
    public String getEmployeeDetails(int staffId) {
        return "Employee details for ID: " + staffId;
    }

    @Override
    public String updateEmployee(int staffId, String staffRole, 
                                  double staffSalary) {
        return "Employee " + staffId + " updated: " + 
               staffRole + " salary: " + staffSalary;
    }

    @Override
    public String removeEmployee(int staffId) {
        return "Employee " + staffId + " removed successfully";
    }
}
package com.hotel.security;
import org.springframework.stereotype.Service;
@Service
public class AccessControlImpl implements IAccessControl {

	@Override
	public void staffAccess(int staffId, String staffName, String staffMail, String staffSchedule, String staffRole,
			double staffSalary) {
		// TODO Auto-generated method stub
		System.out.println("staff id:"+ staffId+"accessed the system."+ "staff details:"+ staffName+ staffMail+ staffSchedule+ staffRole);
	}

	@Override
	public void guestAccess(int guestId, String guestName, String guestMail, String guestPayments,
			String guestData) {
		// TODO Auto-generated method stub
		System.out.println("guest id:"+ guestId+"accessed the system."+ "guest details:"+ guestName+ guestMail+ guestPayments+ guestData);
		
	}

	@Override
	public String checkStaffPermission(int staffId) {
		// TODO Auto-generated method stub
		return "Staff ID: " + staffId + " has permission to access the system";
	}

	@Override
	public String checkGuestPermission(int guestId) {
		// TODO Auto-generated method stub
		return "Guest ID: " + guestId + " has permission to access the system";
	}

	@Override
	public String deleteStaffAccess(int staffId) {
		// TODO Auto-generated method stub
		return "staff id:"+ staffId+" no longer has access";
	}

	@Override
	public String deleteGuestAccess(int guestId) {
		// TODO Auto-generated method stub
		return "guest id:"+ guestId+" no longer has access";

	}

}

package com.hotel.billing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/billing")
public class BillingController {
	@Autowired
	private IAccounting accounting;
	
	@Autowired
	private IBillingAndPayment billingAndPayment;
	
	@Autowired
	private ISalesAndEvent salesAndEvent;
	
	@PostMapping("/accounting/record")
	public String recordTransaction(@RequestParam String cardHolderName,
									@RequestParam int guestId,
									@RequestParam String guestName,
									@RequestParam String recentReciept,
									@RequestParam String guestData,
									@RequestParam String salesAndEvent,
									@RequestParam String promoCode) {
		accounting.recordTransaction(cardHolderName, guestId, guestName, recentReciept, guestData, salesAndEvent, promoCode);
		return "a transaction recorded for:"+ guestName;
	}
	@GetMapping("/accounting/report")
	public 	String getFinancialReport(@RequestParam String financialReport,
									  @RequestParam String guestName,
									  @RequestParam String guestData,
									  @RequestParam String salesAndEvent,
									  @RequestParam String promoCode) {
		accounting.getFinancialReport(financialReport, guestName, guestData, salesAndEvent, promoCode);
		return "getting financial report for: " +guestName;
	}
	@PostMapping("/accounting/refund")
	public 	String requestRefund(@RequestParam String cardHolderName,
								 @RequestParam int guestId,
								 @RequestParam String guestName,
								 @RequestParam String recentReceipt,
								 @RequestParam String guestData) {
		accounting.requestRefund(cardHolderName, guestId, guestName, recentReceipt, guestData);
		return "refund requested for:" +guestName;
		
	}
	@GetMapping("/accounting/getBalance")
	String getAccountBalance(@RequestParam String cardHolderName,
							 @RequestParam int guestId,
							 @RequestParam double currentBalance ) {
		accounting.getAccountBalance(cardHolderName, guestId, currentBalance);
		return "getting account balance for:"+ guestId;
	}
	
	@PostMapping("/billingAndPayment/generateBill")
	public String generateBill(@RequestParam int guestId,
							   @RequestParam String guestName,
							   @RequestParam String checkIn,
							   @RequestParam String checkOut  ) {
		billingAndPayment.generateBill(guestId, guestName, checkIn, checkOut);
		return "generating bill for:" + guestName;
	}
	@PostMapping("/billingAndPayment/reservation")
	public String getReservation(@RequestParam int guestId,
								 @RequestParam String guestName,
								 @RequestParam int roomNumber,
								 @RequestParam String checkIn,
								 @RequestParam String checkOut) {
		billingAndPayment.getReservation(guestId, guestName, roomNumber, checkIn, checkOut);
		return "getting reservation for:" +guestName;
	}
	@GetMapping("/billingAndPayment/discount")
	public 	String applyDiscount(@RequestParam int guestId,
								 @RequestParam String promoCode,
								 @RequestParam double eventPrice) {
		billingAndPayment.applyDiscount(guestId, promoCode, eventPrice);
		return "applying discount" + promoCode;
		
	}
	@GetMapping("/billingAndPayment/history")
	public 	String getBillingHistory(@RequestParam String cardHolderName,
									 @RequestParam int guestId,
									 @RequestParam String guestName,
									 @RequestParam String recentReceipt,
									 @RequestParam String guestData,
									 @RequestParam String salesAndEvent,
									 @RequestParam String promoCode) {
		billingAndPayment.getBillingHistory(cardHolderName, guestId, guestName, recentReceipt, guestData, salesAndEvent, promoCode);
		return "getting billing history for:"+ guestName;
	}
	
	@PostMapping("/salesAndEvent/event")
	public String bookEvent(@RequestParam int guestId,
							@RequestParam String guestName,
							@RequestParam String eventName,
							@RequestParam double eventPrice,
							@RequestParam double eventSales ) {
		salesAndEvent.bookEvent(guestId, guestName, eventName, eventPrice, eventSales);
		return "booking event for:"+ guestName; 
	}
	@DeleteMapping("/salesAndEvent/cancel")
	public 	String cancelEvent(@RequestParam int guestId,
							   @RequestParam String guestName,
							   @RequestParam String eventName,
							   @RequestParam double eventPrice, 
							   @RequestParam double eventSales ) {
		salesAndEvent.cancelEvent(guestId, guestName, eventName, eventPrice, eventSales);
		return "cancelling event for:" +guestName;
	}
	@GetMapping("/salesAndEvent/salesReport")
	public 	String getSalesReport(@RequestParam int guestId,
								  @RequestParam String guestName,
								  @RequestParam String eventName,
								  @RequestParam double eventPrice,
								  @RequestParam double eventSales ) {
		salesAndEvent.getSalesReport(guestId, guestName, eventName, eventPrice, eventSales);
		return "getting sales report for:" + guestName;
	}
	@GetMapping("/salesAndEvent/salesData")
	public 	String guestSalesData(@RequestParam int guestId,
								  @RequestParam String guestName,
								  @RequestParam String eventName,
								  @RequestParam double eventPrice,
								  @RequestParam double eventSales,
								  @RequestParam String promoCode ) {
		salesAndEvent.guestSalesData(guestId, guestName, eventName, eventPrice, eventSales, promoCode);
		return "getting sales data for:"+ guestName;
	}
	@GetMapping("/salesAndEvent/history")
	public 	String getSalesHistory(@RequestParam int guestId) {
		salesAndEvent.getSalesHistory(guestId);
		return "getting sales history for guest number:"+ guestId;
	}
	@GetMapping("salesAndEvent/voucher")
	public 	String addVoucher(@RequestParam int guestId,
							  @RequestParam String promoCode,
							  @RequestParam double eventPrice) {
		salesAndEvent.addVoucher(guestId, promoCode, eventPrice);
		return "adding voucher for guest number:"+ guestId;
	}
	
	@GetMapping("/salesAndEvent/getAll")
	public String getSalesAndEvents(@RequestParam int guestId) {
	    return salesAndEvent.getSalesAndEvents(guestId);
	}






	
	
	
}

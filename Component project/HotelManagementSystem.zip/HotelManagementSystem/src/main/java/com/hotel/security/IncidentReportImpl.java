package com.hotel.security;

import org.springframework.stereotype.Service;

@Service
public class IncidentReportImpl implements IIncidentReport {

    @Override
    public void reportGuestIncident(int guestId, String report) {
        System.out.println("Guest incident reported for guest: " + guestId + 
                           " report: " + report);
    }

    @Override
    public void reportStaffIncident(int staffId, String report) {
        System.out.println("Staff incident reported for staff: " + staffId + 
                           " report: " + report);
    }

    @Override
    public String getIncidentReport(int incidentId) {
        return "Incident report for incident: " + incidentId;
    }

    @Override
    public String updateIncidentReport(int incidentId, String update) {
        return "Incident: " + incidentId + 
               " updated with: " + update;
    }

    @Override
    public String resolveIncident(int incidentId) {
        return "Incident: " + incidentId + 
               " has been resolved";
    }
}
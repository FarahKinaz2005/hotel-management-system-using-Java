package com.hotel.kitchen;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/kitchen")
public class KitchenController {

    @Autowired
    private IMenuManager menuManager;

    @Autowired
    private IOrders orders;

    @Autowired
    private IRoomService roomService;

    @Autowired
    private IRecipeandInventory recipeInventory;

    @Autowired
    private IFoodAndEquipmentRestock restock;

     @PostMapping("/menu/create")
    public String createMenu(@RequestParam String menu,
                             @RequestParam int itemId,
                             @RequestParam boolean itemAvailability,
                             @RequestParam double price) {
        menuManager.createMenu(menu, itemId, itemAvailability, price);
        return "Menu created: " + menu;
    }

    @GetMapping("/menu/get")
    public String getMenu(@RequestParam String menu) {
        return menuManager.getMenu(menu);
    }

    @DeleteMapping("/menu/delete")
    public String deleteItem(@RequestParam int itemId) {
        return menuManager.deleteItem(itemId);
    }

    @PutMapping("/menu/update")
    public String updateItem(@RequestParam int itemId,
                             @RequestParam boolean itemAvailability,
                             @RequestParam double price) {
        return menuManager.updateItem(itemId, itemAvailability, price);
    }

     @PostMapping("/orders/place")
    public String placeOrder(@RequestParam int orderId,
                             @RequestParam int guestId,
                             @RequestParam String placeOrder) {
        orders.placeOrder(orderId, guestId, placeOrder);
        return "Order placed: " + orderId;
    }

    @GetMapping("/orders/track")
    public String trackOrder(@RequestParam int orderId) {
        return orders.trackOrder(orderId);
    }

    @GetMapping("/orders/restock")
    public String restockAlert(@RequestParam int productId,
                               @RequestParam boolean productAvailability,
                               @RequestParam int numProducts,
                               @RequestParam String productName) {
        return orders.restockAlert(productId, productAvailability, 
                                   numProducts, productName);
    }

    @DeleteMapping("/orders/cancel")
    public String cancelOrder(@RequestParam int orderId) {
        return orders.orderCancellation(orderId);
    }

     @PostMapping("/roomservice/order")
    public String orderFood(@RequestParam int guestId,
                            @RequestParam int roomNumber,
                            @RequestParam String orderDetails,
                            @RequestParam int orderId) {
        roomService.orderFood(guestId, roomNumber, orderDetails, orderId);
        return "Room service order placed for room: " + roomNumber;
    }

    @GetMapping("/roomservice/prepare")
    public String prepareOrder(@RequestParam String orderDetails,
                               @RequestParam int orderId) {
        return roomService.prepareOrder(orderDetails, orderId);
    }

    @GetMapping("/roomservice/track")
    public String trackRoomOrder(@RequestParam int orderId) {
        return roomService.trackOrder(orderId);
    }

    @PostMapping("/roomservice/special")
    public String specialRequest(@RequestParam String requestDetails) {
        return roomService.specialRequest(requestDetails);
    }

     @PostMapping("/inventory/store")
    public String storeRecipe(@RequestParam int recipeId,
                              @RequestParam String recipeIngredients,
                              @RequestParam int ingredientId) {
        recipeInventory.storeRecipe(recipeId, recipeIngredients, ingredientId);
        return "Recipe stored: " + recipeId;
    }

    @GetMapping("/inventory/track")
    public String trackStock(@RequestParam int ingredientId) {
        return recipeInventory.trackIngredientStock(ingredientId);
    }

    @GetMapping("/inventory/availability")
    public String checkAvailability(@RequestParam int ingredientId,
                                    @RequestParam boolean ingredientAvailability) {
        return recipeInventory.availability(ingredientId, ingredientAvailability);
    }

    @PutMapping("/inventory/update")
    public String updateInventory(@RequestParam int ingredientId,
                                  @RequestParam int stockNumber) {
        return recipeInventory.updateIngredientAvailability(ingredientId, stockNumber);
    }

    @GetMapping("/inventory/alert")
    public String stockAlert(@RequestParam int ingredientId,
                             @RequestParam String alertStock,
                             @RequestParam int stockNumber) {
        return recipeInventory.stockAlert(ingredientId, alertStock, stockNumber);
    }

     @GetMapping("/restock/alert")
    public String getRestockAlert(@RequestParam int ingredientId,
                                  @RequestParam boolean ingredientAvailability) {
        restock.getRestockAlert(ingredientId, ingredientAvailability);
        return "Restock alert received for: " + ingredientId;
    }

    @PostMapping("/restock/request")
    public String stockRequest(@RequestParam int ingredientId) {
        return restock.stockRequest(ingredientId);
    }

    @PostMapping("/restock/delivery")
    public String deliveryConfirmation(@RequestParam int ingredientOrderId,
                                       @RequestParam String orderDetails,
                                       @RequestParam String deliveryDate) {
        return restock.deliveryConfirmation(ingredientOrderId, 
                                            orderDetails, deliveryDate);
    }

    @PutMapping("/restock/inventory")
    public String updateRestockInventory(@RequestParam int ingredientId,
                                         @RequestParam int stockNumber) {
        return restock.updateInventory(ingredientId, stockNumber);
    }
}
package com.hotel.services;

public interface ISpaService {
    void bookSpaSession(String guestName, String sessionType);
    void cancelBooking(String guestName, int bookingId);
    String checkSpaAvailability(String date);
    String getSpaMenu();
}
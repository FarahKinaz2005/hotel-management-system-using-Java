package com.hotel.payment;

public class ExternalPaymentGatewayImpl implements IExternalPaymentGateway {

    @Override
    public boolean processPayment(int guestId, String cardNumber, 
                                   double amount, String cardType) {
        System.out.println("Processing payment for guest: " + guestId + 
                           " amount: " + amount + 
                           " card type: " + cardType);
        return true;
    }

    @Override
    public String confirmPayment(int guestId, double amount) {
        return "Payment confirmed for guest: " + guestId + 
               " amount: " + amount;
    }

    @Override
    public String refundPayment(int guestId, double amount) {
        return "Refund processed for guest: " + guestId + 
               " amount: " + amount;
    }

    @Override
    public String getPaymentStatus(int guestId) {
        return "Payment status for guest: " + guestId + ": Completed";
    }
}
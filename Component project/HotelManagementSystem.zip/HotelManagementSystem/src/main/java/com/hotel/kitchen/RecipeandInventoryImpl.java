package com.hotel.kitchen;
import org.springframework.stereotype.Service;
@Service
public class RecipeandInventoryImpl implements IRecipeandInventory {

	@Override
	public void storeRecipe(int recipeId, String recipeIngredients, int ingredientId) {
	    System.out.println("Storing recipe: " + recipeId + 
	                       " ingredients: " + recipeIngredients + 
	                       " ingredientId: " + ingredientId);
	}
	@Override
	public String trackIngredientStock(int ingredientId) {
	    return "Tracking stock for ingredient: " + ingredientId;
	}

	@Override
	public String availability(int ingredientId, boolean ingredientAvailability) {
	    return "Ingredient: " + ingredientId + 
	           " available: " + ingredientAvailability;
	}

	@Override
	public String updateIngredientAvailability(int ingredientId, int stockNumber) {
	    return "Updated ingredient: " + ingredientId + 
	           " stock to: " + stockNumber;
	}

	@Override
	public String stockAlert(int ingredientId, String alertStock, int stockNumber) {
	    return "Alert: " + alertStock + 
	           " for ingredient: " + ingredientId + 
	           " remaining stock: " + stockNumber;
	}

}

package com.hotel.services;

import org.springframework.stereotype.Service;

@Service
public class ReservationInformationImpl implements IReservationInformation {

    @Override
    public void createReservation(String guestName, int roomNumber, 
                                   String date) {
        System.out.println("Reservation created for " + guestName + 
                           " room " + roomNumber + " on " + date);
    }

    @Override
    public void cancelReservation(int reservationId) {
        System.out.println("Reservation " + reservationId + " cancelled");
    }

    @Override
    public void modifyReservation(int reservationId, String newDate) {
        System.out.println("Reservation " + reservationId + 
                           " modified to " + newDate);
    }

    @Override
    public String checkAvailability(String date) {
        return "Rooms available on " + date + ": 101, 102, 205";
    }

    @Override
    public String getReservationDetails(int reservationId) {
        return "Reservation " + reservationId + ": Guest John, Room 101";
    }
}
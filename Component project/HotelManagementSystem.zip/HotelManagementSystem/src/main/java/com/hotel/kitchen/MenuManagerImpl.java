package com.hotel.kitchen;
import org.springframework.stereotype.Service;
@Service 
public class MenuManagerImpl implements IMenuManager{

	@Override
	public void createMenu(String menu, int itemId, boolean itemAvailability, double price) {
		// TODO Auto-generated method stub
		System.out.println("New Menu:"+ menu+ " , "+ itemId+" , "+ itemAvailability+" , "+ price);
	}

	@Override
	public String getMenu(String menu) {
		// TODO Auto-generated method stub
		return "Current menu:" + menu;
	}

	@Override
	public String deleteItem(int itemId) {
		// TODO Auto-generated method stub
		return "Item number"+ itemId+" deleted successfully";
	}

	@Override
	public String updateItem(int itemId, boolean itemAvailability, double price) {
		// TODO Auto-generated method stub
		return "Item Number"+ itemId+"got updated to:"+ itemAvailability+ " , "+ price;
	}

}

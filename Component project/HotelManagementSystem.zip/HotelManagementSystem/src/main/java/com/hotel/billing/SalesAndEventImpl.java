package com.hotel.billing;
import org.springframework.stereotype.Service;
@Service
public class SalesAndEventImpl implements ISalesAndEvent{

	@Override
	public void bookEvent(int guestId, String guestName, String eventName, double eventPrice, double eventSales) {
		// TODO Auto-generated method stub
		System.out.println("booking event:"+ guestName+ guestId+ eventName+ eventPrice+ eventSales);
	}

	@Override
	public String cancelEvent(int guestId, String guestName, String eventName, double eventPrice, double eventSales) {
		// TODO Auto-generated method stub
		return "cancelling event"+ guestId+ guestName+ eventName+ eventPrice+ eventSales;
	}

	@Override
	public String getSalesReport(int guestId, String guestName, String eventName, double eventPrice,
			double eventSales) {
		// TODO Auto-generated method stub
		return "getting the sales report" + guestId+ guestName+ eventName+ eventPrice+ eventSales;
	}

	@Override
	public String guestSalesData(int guestId, String guestName, String eventName, double eventPrice, double eventSales,
			String promoCode) {
		// TODO Auto-generated method stub
		return "guest sales data:"+ guestId+ guestName+ eventName+ eventPrice+ eventSales+ promoCode;
	}

	@Override
	public String getSalesHistory(int guestId) {
		// TODO Auto-generated method stub
		return "getting sales history from"+ guestId;
	}

	@Override
	public String addVoucher(int guestId, String promoCode, double eventPrice) {
		// TODO Auto-generated method stub
		return "adding voucher"+ guestId+ promoCode+ eventPrice;
	}

	@Override
	public String getSalesAndEvents(int guestId) {
	    return "Sales and events for guest: " + guestId;
	}

}

package com.hotel.services;

import org.springframework.stereotype.Service;

@Service
public class MaintenanceImpl implements IMaintenance {

    @Override
    public void logIssue(int roomNumber, String issue) {
        System.out.println("Issue logged for room " + roomNumber + 
                           ": " + issue);
    }

    @Override
    public void assignTechnician(int roomNumber, String technicianName) {
        System.out.println("Technician " + technicianName + 
                           " assigned to room " + roomNumber);
    }

    @Override
    public String checkIssueStatus(int roomNumber) {
        return "Issue status for room " + roomNumber + ": In Progress";
    }

    @Override
    public String resolveIssue(int roomNumber) {
        return "Issue resolved for room " + roomNumber;
    }
}
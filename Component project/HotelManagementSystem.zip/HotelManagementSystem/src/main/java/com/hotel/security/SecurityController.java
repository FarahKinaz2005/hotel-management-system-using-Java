package com.hotel.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/security")
public class SecurityController {

    @Autowired
    private IAccessControl accessControl;

    @Autowired
    private IIncidentReport incidentReport;

    @PostMapping("/access/staff")
    public String staffAccess(@RequestParam int staffId,
                              @RequestParam String staffName,
                              @RequestParam String staffMail,
                              @RequestParam String staffSchedule,
                              @RequestParam String staffRole,
                              @RequestParam double staffSalary) {
        accessControl.staffAccess(staffId, staffName, staffMail, 
                                  staffSchedule, staffRole, staffSalary);
        return "Access granted for staff: " + staffName;
    }

    @PostMapping("/access/guest")
    public String customerAccess(@RequestParam int guestId,
                                 @RequestParam String guestName,
                                 @RequestParam String guestMail,
                                 @RequestParam String guestPayments,
                                 @RequestParam String guestData) {
        accessControl.guestAccess(guestId, guestName, guestMail, 
                                     guestPayments, guestData);
        return "Access granted for guest: " + guestName;
    }

    @GetMapping("/access/checkStaff")
    public String checkStaffPermission(@RequestParam int staffId) {
        return accessControl.checkStaffPermission(staffId);
    }

    @GetMapping("/access/checkGuest")
    public String checkGuestPermission(@RequestParam int guestId) {
        return accessControl.checkGuestPermission(guestId);
    }

    @DeleteMapping("/access/deleteStaff")
    public String deleteStaffAccess(@RequestParam int staffId) {
        return accessControl.deleteStaffAccess(staffId);
    }

    @DeleteMapping("/access/deleteGuest")
    public String deleteGuestAccess(@RequestParam int guestId) {
        return accessControl.deleteGuestAccess(guestId);
    }

    @PostMapping("/incident/guest")
    public String reportGuestIncident(@RequestParam int guestId,
                                      @RequestParam String report) {
        incidentReport.reportGuestIncident(guestId, report);
        return "Guest incident reported for: " + guestId;
    }

    @PostMapping("/incident/staff")
    public String reportStaffIncident(@RequestParam int staffId,
                                      @RequestParam String report) {
        incidentReport.reportStaffIncident(staffId, report);
        return "Staff incident reported for: " + staffId;
    }

    @GetMapping("/incident/getReport")
    public String getIncidentReport(@RequestParam int incidentId) {
        return incidentReport.getIncidentReport(incidentId);
    }

    @PutMapping("/incident/update")
    public String updateIncidentReport(@RequestParam int incidentId,
                                       @RequestParam String update) {
        return incidentReport.updateIncidentReport(incidentId, update);
    }

    @PutMapping("/incident/resolve")
    public String resolveIncident(@RequestParam int incidentId) {
        return incidentReport.resolveIncident(incidentId);
    }
}
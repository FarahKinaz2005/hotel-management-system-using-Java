package com.hotel.services;

public interface IReservationInformation {
    void createReservation(String guestName, int roomNumber, String date);
    void cancelReservation(int reservationId);
    void modifyReservation(int reservationId, String newDate);
    String checkAvailability(String date);
    String getReservationDetails(int reservationId);
}
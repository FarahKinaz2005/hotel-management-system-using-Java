package com.hotel.kitchen;

public interface IRoomService {
	void orderFood(int guestId, int roomNumber, String orderDetails, int orderId);
	String prepareOrder(String orderDetails, int orderId);
	String trackOrder(int orderId);
	String specialRequest(String requestDetails);
}

package com.hotel.services;

import org.springframework.stereotype.Service;

@Service
public class ConciergeServiceImpl implements IConciergeService {

    @Override
    public void handleGuestRequest(String guestName, String request) {
        System.out.println("Request from " + guestName + ": " + request);
    }

    @Override
    public void bookTaxi(String guestName, String destination) {
        System.out.println("Taxi booked for " + guestName + 
                           " to " + destination);
    }

    @Override
    public void arrangeTouring(String guestName, String tourName) {
        System.out.println("Tour arranged for " + guestName + 
                           ": " + tourName);
    }

    @Override
    public String getAvailableServices() {
        return "Available: Taxi, Tours, Restaurant Booking, Laundry";
    }
}
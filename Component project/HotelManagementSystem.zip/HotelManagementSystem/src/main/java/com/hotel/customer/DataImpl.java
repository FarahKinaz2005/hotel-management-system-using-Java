package com.hotel.customer;
import org.springframework.stereotype.Service;
@Service
public class DataImpl implements IData{

	@Override
	public void getReservation(int guestId, String guestName, int roomNumber, String checkIn, String checkOut) {
		// TODO Auto-generated method stub
		System.out.println("Storing"+ guestId+" , "+ guestName+" , "+ roomNumber+" , "+ checkIn+" and "+ checkOut+" in Guest's data history ");
	}

	@Override
	public String getBillingVerification(Boolean approval, String billingData) {
		// TODO Auto-generated method stub
 
		return "Storing"+ approval+" and "+ billingData+" in Guest's data history  ";
	}

	@Override
	public String visaData(String cardHolderName, String cardNumber, String cardCVV, String expireDate,
			String cardType) {
		// TODO Auto-generated method stub
 
		return "Storing"+ cardHolderName+" and "+ cardNumber+" , "+ cardCVV+ " , "+ expireDate+ " in Guest's data history  ";
	}

	@Override
	public String retrieveGuestData(int guestId) {
		// TODO Auto-generated method stub
 		return "Returning Guest's Id:"+ guestId;
	}

	@Override
	public String getVerifiedGuestData(int guestId) {
	    return "Verified guest data for ID: " + guestId;
	}

	@Override
	public void saveToDatabase(String data) {
	    System.out.println("Saving to database: " + data);
	}

	@Override
	public String retrieveFromDatabase(int id) {
	    return "Retrieved data for ID: " + id;
	}

}

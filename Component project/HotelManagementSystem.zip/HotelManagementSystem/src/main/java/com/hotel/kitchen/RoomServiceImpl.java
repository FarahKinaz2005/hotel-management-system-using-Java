package com.hotel.kitchen;
import org.springframework.stereotype.Service;
@Service
public class RoomServiceImpl implements IRoomService{

	@Override
	public void orderFood(int guestId, int roomNumber, String orderDetails, int orderId) {
		// TODO Auto-generated method stub
		System.out.println("guest: "+ guestId+ " from room number: "+ roomNumber +" had requested to order"+ orderDetails+orderId);
	}

	@Override
	public String prepareOrder(String orderDetails, int orderId) {
		// TODO Auto-generated method stub
		return "Prepairing"+ orderDetails+ orderId;
	}

	@Override
	public String trackOrder(int orderId) {
		// TODO Auto-generated method stub
		return "tracking Order number:"+orderId;
	}

	@Override
	public String specialRequest(String requestDetails) {
		// TODO Auto-generated method stub
		return "Special request:"+ requestDetails;
	}

}

package com.hotel.billing;

public interface IAccounting {
	void recordTransaction(String cardHolderName, int guestId, String guestName, String recentReciept,String guestData, String salesAndEvent, String promoCode);
	String getFinancialReport(String financialReport, String guestName, String guestData,String salesAndEvent, String promoCode);
	String requestRefund(String cardHolderName, int guestId, String guestName, String recentReceipt,String guestData);
	String getAccountBalance(String cardHolderName, int guestId, double currentBalance );
	String getBillingCustomerData(int guestId, String guestName);
}

package com.hotel.staff;

import org.springframework.stereotype.Service;

@Service
public class ShiftScheduleImpl implements IShiftSchedule {

    @Override
    public void createShift(int staffId, String shiftDate, 
                             String startTime, String endTime) {
        System.out.println("Shift created for staff: " + staffId + 
                           " date: " + shiftDate + 
                           " from: " + startTime + 
                           " to: " + endTime);
    }

    @Override
    public String getWeeklySchedule(int staffId) {
        return "Weekly schedule for staff: " + staffId;
    }

    @Override
    public String updateShift(int staffId, String shiftDate, 
                               String newStartTime, String newEndTime) {
        return "Shift updated for staff: " + staffId + 
               " date: " + shiftDate + 
               " new time: " + newStartTime + 
               " to " + newEndTime;
    }

    @Override
    public String cancelShift(int staffId, String shiftDate) {
        return "Shift cancelled for staff: " + staffId + 
               " on: " + shiftDate;
    }
}
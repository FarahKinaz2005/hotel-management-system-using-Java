package com.hotel.staff;

import org.springframework.stereotype.Service;

@Service
public class RolesImpl implements IRoles {

    @Override
    public void assignRole(int staffId, String roleName) {
        System.out.println("Role " + roleName + 
                           " assigned to staff: " + staffId);
    }

    @Override
    public String getRolePermissions(String roleName) {
        return "Permissions for role " + roleName + 
               ": Read, Write, Execute";
    }

    @Override
    public String updateRole(int staffId, String newRole) {
        return "Staff " + staffId + 
               " role updated to: " + newRole;
    }

    @Override
    public String removeRole(int staffId, String roleName) {
        return "Role " + roleName + 
               " removed from staff: " + staffId;
    }
}
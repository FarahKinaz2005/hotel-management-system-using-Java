package com.hotel.kitchen;

public interface IOrders {
	void placeOrder(int orderId, int guestId, String placeOrder);
	String trackOrder(int orderId);
	String restockAlert(int productId, boolean productAvailability, int numProducts, String productName);
	String orderCancellation(int orderId);
}
